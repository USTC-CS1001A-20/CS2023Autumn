#include <stdio.h>
//请参考P51注释
int main(){
    char c;
    unsigned short s;
    double d;
    printf("Input one char: ");
    c = ;//TODO: 从键盘上输入一个字符
    printf("ASCII:%d\n", c);
    printf("Input one short: ");
    scanf(/*___*/);//TODO: 请参考P51注释
    printf("unsigned short:%u\n", s);
    printf("Input one real: ");
    scanf(/*___*/);//TODO: 请参考P51注释
    printf("double:%g\n", d);
    return 0;
}